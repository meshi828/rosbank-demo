from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_session
from ..models import Account, Payment, Transaction
from ..schemas import PaymentCreate, PaymentOut
from ..auth import get_current_user
from ..fraud import evaluate_rules
from ..connectors.mock_banks import sbp_send_payment
from datetime import datetime

router = APIRouter(prefix="/payments", tags=["payments"])

@router.post("", response_model=PaymentOut)
async def create_payment(payload: PaymentCreate, background: BackgroundTasks, session: AsyncSession = Depends(get_session), user=Depends(get_current_user)):
    # Валидации
    res = await session.execute(select(Account).where(Account.id == payload.from_account_id))
    account = res.scalar_one_or_none()
    if not account or account.user_id != user.id:
        raise HTTPException(status_code=404, detail="Account not found")
    if account.currency != payload.currency:
        raise HTTPException(status_code=400, detail="Currency mismatch")
    if account.balance < payload.amount:
        raise HTTPException(status_code=400, detail="Insufficient funds")

    # Антифрод
    results = evaluate_rules(payload.amount, payload.channel, payload.to)
    if any(not r.ok for r in results):
        raise HTTPException(status_code=403, detail="Fraud check failed: " + ",".join(r.reason for r in results if not r.ok))

    # Проведение
    receipt = ""
    status = "succeeded"
    if payload.channel == "sbp":
        r = sbp_send_payment(account.iban, payload.to, payload.amount)
        receipt = f"SBP RRN={r['rrn']}"
    elif payload.channel == "internal":
        receipt = "Internal transfer OK"
    else:
        raise HTTPException(status_code=400, detail="Unknown channel")

    account.balance -= payload.amount
    p = Payment(user_id=user.id, from_account_id=account.id, to=payload.to, channel=payload.channel,
                amount=payload.amount, currency=payload.currency, status=status, receipt=receipt)
    session.add(p)
    await session.commit()
    await session.refresh(p)

    tr = Transaction(account_id=account.id, amount=-payload.amount, currency=payload.currency,
                     description=f"Payment to {payload.to} via {payload.channel}", category="payment")
    session.add(tr)
    await session.commit()

    return p

@router.get("", response_model=list[PaymentOut])
async def list_payments(session: AsyncSession = Depends(get_session), user=Depends(get_current_user)):
    res = await session.execute(select(Payment).where(Payment.user_id == user.id))
    return list(res.scalars())
