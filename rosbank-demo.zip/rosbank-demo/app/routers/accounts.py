from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_session
from ..models import Account, Transaction
from ..schemas import AccountOut, TransactionOut
from ..auth import get_current_user
from ..connectors.mock_banks import sber_get_accounts, vtb_get_accounts, tinkoff_get_accounts

router = APIRouter(prefix="/accounts", tags=["accounts"])

@router.get("", response_model=list[AccountOut])
async def list_accounts(session: AsyncSession = Depends(get_session), user=Depends(get_current_user)):
    res = await session.execute(select(Account).where(Account.user_id == user.id))
    accounts = list(res.scalars())
    # Подгрузим мок-аккаунты «из других банков», если их ещё нет
    if not any(a.bank == "sber" for a in accounts):
        for it in sber_get_accounts(user.email):
            accounts.append(Account(user_id=user.id, bank="sber", iban=it["iban"], currency=it["currency"], balance=it["balance"]))
    if not any(a.bank == "vtb" for a in accounts):
        for it in vtb_get_accounts(user.email):
            accounts.append(Account(user_id=user.id, bank="vtb", iban=it["iban"], currency=it["currency"], balance=it["balance"]))
    if not any(a.bank == "tinkoff" for a in accounts):
        for it in tinkoff_get_accounts(user.email):
            accounts.append(Account(user_id=user.id, bank="tinkoff", iban=it["iban"], currency=it["currency"], balance=it["balance"]))
    return accounts

@router.get("/{account_id}/transactions", response_model=list[TransactionOut])
async def list_transactions(account_id: int, session: AsyncSession = Depends(get_session), user=Depends(get_current_user)):
    res = await session.execute(select(Transaction).where(Transaction.account_id == account_id))
    return list(res.scalars())
