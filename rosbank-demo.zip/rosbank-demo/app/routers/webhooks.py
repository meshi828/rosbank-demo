from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, HttpUrl
import httpx, anyio
from ..auth import get_current_user
from ..settings import settings

router = APIRouter(prefix="/webhooks", tags=["webhooks"])

class WebhookPayload(BaseModel):
    url: HttpUrl
    event: str
    data: dict

async def _post_with_retries(url: str, json: dict, retries: int):
    for i in range(retries):
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                r = await client.post(url, json=json)
                if r.status_code < 400:
                    return True
        except Exception:
            pass
        await anyio.sleep(0.5 * (i + 1))
    return False

@router.post("")
async def send_webhook(body: WebhookPayload, user=Depends(get_current_user)):
    ok = await _post_with_retries(str(body.url), {"event": body.event, "data": body.data, "user": user.email}, settings.webhook_max_retries)
    if not ok:
        raise HTTPException(status_code=502, detail="Webhook delivery failed")
    return {"status": "delivered"}
