from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_session, Base, engine
from ..models import User, Account, Transaction
from ..schemas import UserCreate, Token, UserOut
from ..auth import hash_password, verify_password, create_access_token
from datetime import timedelta

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/register", response_model=UserOut)
async def register(data: UserCreate, session: AsyncSession = Depends(get_session)):
    res = await session.execute(select(User).where(User.email == data.email))
    if res.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(email=data.email, hashed_password=hash_password(data.password), is_admin=False)
    session.add(user)
    await session.commit()
    await session.refresh(user)
    # Создадим локальный счёт
    acc = Account(user_id=user.id, bank="local", iban=f"RU00LOCAL{user.id:010d}", currency="RUB", balance=10000.0)
    session.add(acc)
    await session.commit()
    # Стартовая транзакция
    tr = Transaction(account_id=acc.id, amount=10000.0, currency="RUB", description="Initial top-up", category="income")
    session.add(tr)
    await session.commit()
    return user

@router.post("/login", response_model=Token)
async def login(data: UserCreate, session: AsyncSession = Depends(get_session)):
    res = await session.execute(select(User).where(User.email == data.email))
    user = res.scalar_one_or_none()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    token = create_access_token({"sub": user.id}, expires_delta=timedelta(minutes=60))
    return {"access_token": token, "token_type": "bearer"}
