# Моковые коннекторы к «банкам» — заглушки под реальную интеграцию.
from typing import Dict, List

def sber_get_accounts(user_email: str) -> List[Dict]:
    return [
        {"iban": "RU00SBER00000000000001", "balance": 150000.50, "currency": "RUB"},
    ]

def vtb_get_accounts(user_email: str) -> List[Dict]:
    return [
        {"iban": "RU00VTB00000000000001", "balance": 42000.00, "currency": "RUB"},
    ]

def tinkoff_get_accounts(user_email: str) -> List[Dict]:
    return [
        {"iban": "RU00TCS00000000000001", "balance": 77777.77, "currency": "RUB"},
    ]

def sbp_send_payment(from_iban: str, to_phone: str, amount: float) -> Dict:
    # Возвращаем фальш-квитанцию
    return {
        "provider": "SBP",
        "from": from_iban,
        "to": to_phone,
        "amount": amount,
        "status": "ACCEPTED",
        "rrn": "999999999999",
    }
