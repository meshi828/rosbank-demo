import asyncio
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlalchemy import text
from .settings import settings
from .db import engine, Base
from .routers import auth_router, accounts, payments, webhooks

app = FastAPI(title=settings.app_name, version="0.1.0")

app.include_router(auth_router.router)
app.include_router(accounts.router)
app.include_router(payments.router)
app.include_router(webhooks.router)

@app.on_event("startup")
async def on_startup():
    # Создание таблиц без Alembic для простоты демо
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

@app.get("/", tags=["meta"])
async def root():
    return {"name": settings.app_name, "docs": "/docs"}
