from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6)

class UserOut(BaseModel):
    id: int
    email: EmailStr
    is_admin: bool
    created_at: datetime
    class Config:
        from_attributes = True

class AccountOut(BaseModel):
    id: int
    bank: str
    iban: str
    currency: str
    balance: float
    created_at: datetime
    class Config:
        from_attributes = True

class TransactionOut(BaseModel):
    id: int
    amount: float
    currency: str
    description: str
    category: str
    created_at: datetime
    class Config:
        from_attributes = True

class PaymentCreate(BaseModel):
    from_account_id: int
    to: str
    channel: str  # internal/sbp
    amount: float
    currency: str = "RUB"

class PaymentOut(BaseModel):
    id: int
    user_id: int
    from_account_id: int
    to: str
    channel: str
    amount: float
    currency: str
    status: str
    receipt: str
    created_at: datetime
    class Config:
        from_attributes = True
