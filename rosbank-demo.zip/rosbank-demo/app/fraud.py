from dataclasses import dataclass
from typing import List

@dataclass
class RuleResult:
    ok: bool
    reason: str = ""

def evaluate_rules(amount: float, channel: str, to: str) -> List[RuleResult]:
    rules = []
    # Example rules
    if amount > 500_000:
        rules.append(RuleResult(ok=False, reason="amount_over_limit"))
    if channel == "sbp" and not to.startswith("+7"):
        rules.append(RuleResult(ok=False, reason="sbp_requires_russian_phone"))
    if to.endswith("0000"):
        rules.append(RuleResult(ok=False, reason="suspicious_recipient_pattern"))
    if not rules:
        rules.append(RuleResult(ok=True, reason="ok"))
    return rules
