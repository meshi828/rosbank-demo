# ROSBANK Demo — Моковый API для онлайн-банка (FastAPI)

> Крутой демо-репозиторий «как у банка»: авторизация по JWT, счета, транзакции, платежи через «СБП» (мок), вебхуки и антифрод-правила. Готово к запуску в Docker.

## Возможности
- 🔐 Регистрация/логин пользователей, JWT, роли (user/admin)
- 🧾 Счета и баланс, категории транзакций
- 💸 Платежи (внутренние и «СБП»-мок), статусы, квитанции
- 📡 Вебхуки на внешние адреса + ретраи
- 🕵️ Антифрод-правила (простейший rule engine)
- 🗂️ Подключения к банкам (Sber/VTB/Tinkoff — мок-коннекторы)
- 🧪 Тесты (pytest) и CI (GitHub Actions)
- 📜 Полная OpenAPI-документация в /docs

> **Примечание:** это учебный проект. Он не связан с реальными банками и не предназначен для продакшена.

## Быстрый старт (без Docker)
```bash
python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Затем откройте: http://127.0.0.1:8000/docs

## Запуск в Docker
```bash
docker compose up --build
```
По умолчанию API поднимется на `http://localhost:8000` (SQLite). 
Для PostgreSQL раскомментируйте блок `postgres` в `docker-compose.yml` и переменные в `.env`.

## Примеры
1) Зарегистрируйте пользователя: `POST /auth/register`
2) Войдите: `POST /auth/login` — получите JWT
3) Посмотрите счета: `GET /accounts` (с токеном)
4) Создайте платёж: `POST /payments` (тип `sbp` или `internal`)

## Скриншоты
- OpenAPI UI: */docs*
- Redoc: */redoc*

## Архитектура
- **FastAPI** + **SQLAlchemy** (SQLite по умолчанию)
- **passlib[bcrypt]** для хешей паролей
- **PyJWT** для токенов
- **HTTPX** для отправки вебхуков
- Модули: `routers/`, `connectors/`, `auth.py`, `fraud.py`

## Лицензия
MIT
